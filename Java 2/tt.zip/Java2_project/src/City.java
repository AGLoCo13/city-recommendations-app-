import java.io.IOException;
import java.net.URL;
import java.util.Scanner;
import java.util.Vector;

import com.fasterxml.jackson.databind.ObjectMapper;
import weather.OpenWeatherMap;
import wikipedia.MediaWiki;
public class City {
	int n=10;
	String cityName,country;
	float cafe,sea,restaurant,museum,stadium,mountain,etc,temperature,latitude,longtitude,clouds;
	public void RetrieveData(String city, String country, String appid) throws  IOException {
		 ObjectMapper mapper = new ObjectMapper(); 
		 //Initializing connection with OpenWeatherMap API
		 OpenWeatherMap weather_obj = mapper.readValue(new URL("http://api.openweathermap.org/data/2.5/weather?q="+city+","+country+"&APPID="+appid+""), OpenWeatherMap.class);
		 //Getting the temperature and assigning it to a float value
		 //Getting the latitude and assigning it to a float value
		 //Getting the longitude and assigning it to a float value
		 temperature = weather_obj.getMain().getTemp().floatValue();
		 latitude=weather_obj.getCoord().getLon().floatValue();
		 longtitude=weather_obj.getCoord().getLat().floatValue();
		 //clouds percentage is taken from the getClouds object, i first convert it to String
		 clouds = weather_obj.getClouds().getAll().floatValue();
		 //Then,to float
		  //initializing connection with MediaWiki API
		 MediaWiki mediaWiki_obj =  mapper.readValue(new URL("https://en.wikipedia.org/w/api.php?action=query&prop=extracts&titles="+city+"&format=json&formatversion=2"),MediaWiki.class);
		 //Getting the Json and parsing it to a String named WikiJson
		 String wikiJson = mediaWiki_obj.getQuery().getPages().get(0).getExtract();
		 //Using the created StringCounter class to count occurencies of city's features from JsonWiki 
		 cafe = stringCounter.countCriterionfCity(wikiJson, "cafe");
	     sea = stringCounter.countCriterionfCity(wikiJson, "sea");
	     museum = stringCounter.countCriterionfCity(wikiJson, "museum");
	     restaurant = stringCounter.countCriterionfCity(wikiJson,"restaurant");
	     mountain = stringCounter.countCriterionfCity(wikiJson, "mountain");
	     stadium = stringCounter.countCriterionfCity(wikiJson, "stadium");
	     etc = stringCounter.countCriterionfCity(wikiJson, "etc");
	     setCityName(city);
	     setCountry(country);
	     setTerms(cafe,sea,museum,restaurant,mountain,stadium,etc,temperature,clouds,latitude,longtitude);
	     
	}
	//Creating A setter function to set all of the terms found from wikipedia and OpenWeatherMap API
	//This setter is used in RetrieveData function to parse the found terms.
	public void setTerms(float newCafe,float newSea,float newMuseum,float newRestaurant,float newMountain, float newStadium, float newEtc , float newTemperature ,float newClouds, float newLatitude , float newLongitude ) {
		this.cafe = newCafe;
		this.sea = newSea;
		this.museum = newMuseum;
		this.restaurant = newRestaurant;
		this.mountain = newMountain;
		this.stadium = newStadium;
		this.etc = newEtc;
		this.temperature = newTemperature;
		this.latitude = newLatitude;
		this.longtitude = newLongitude;
		this.clouds=newClouds;
	}
	public void setCityName(String newCity) {
		this.cityName = newCity;
	}
	public void setCountry(String newCountry) {
		this.country=newCountry;
	}
	//OpenWeatherMap API key getter
	public String getApiKey(){
		String appid = "87f7ead88749ce59a63c5e0b593dccd4";
		return appid;
	}
	public void setCafe(float newCafe) {
		this.cafe=newCafe;
	}
	public void setSea(float newSea) {
		this.sea = newSea;
	}
	public void setMuseum(float newMuseum) {
		this.museum = newMuseum;
	}
	public void setRestaurant(float newRestaurant) {
		this.restaurant = newRestaurant;
	}
	public void setMountain(float newMountain) {
		this.mountain = newMountain;
	}
	public void setStadium(float newStadium) {
		this.stadium = newStadium;
	}
	public void setEtc(float newEtc) {
		this.etc = newEtc;
	}
	public void setTemperature(float newTemp) {
		this.temperature = newTemp;
	}
	public void setLatitude(float newLatitude) {
		this.latitude = newLatitude;
	}
	public void setLongtitude(float newLongtitude) {
		this.longtitude = newLongtitude;
	}
	public void setClouds(float newClouds) {
		this.clouds = newClouds;
	}
	
	//Getters for all occurencies of city's features 
	public String getCountry() {
		return country;
	}
	public String getCityName() {
		return cityName;
	}
	public float getCafeCount() {
		return cafe;
	}
	public float getSeaCount() {
		return sea;
	}
	public float getMuseumCount() {
		return museum;
	}
	public float getRestaurantCount() {
		return restaurant;
	}
	public float getMountainCount() {
		return mountain;
	}
	public float getStadiumCount() {
		return stadium;
	}
	public float getEtcCount(){
		return etc;
	}
	public float getTemperature() {
		return temperature;
	}
	public float getLatitude() {
		return latitude;
	}
	public float getLongtitude() {
		return longtitude;
	}
	public float getClouds() {
		return clouds;
	}
	public Vector<Float> vectorRepresentation(){
		int n=10;
		float[] terms;
		//Creating a terms array to store each sum of features found
		terms = new float[11];
		//Zero-ing the terms aray
		for(int i=0; i<n; ++i) {
			terms[i]=0.0f;
		}
		terms[0]=getCafeCount();
		terms[1]=getSeaCount();
		terms[2]=getMuseumCount();
		terms[3]=getRestaurantCount();
		terms[4]=getMountainCount();
		terms[5]=getStadiumCount();
		terms[6]=getEtcCount();
		terms[7]=getTemperature();
		terms[8]=getClouds();
		terms[9]=getLatitude();
		terms[10]=getLongtitude();
		//Initializing the Vector Array
		//Normalizing the features
		//TO DO so.. we need another Array named Normalized_terms
		float[] normalizedTerms;
		normalizedTerms = new float[10];
		//Zero-ing the new array
		for(int i=0; i<9; i++) {
			normalizedTerms[i]=0.0f;
		}
		//numbers stored from the arrays' index 0 to 6 are the features before temperature and coordinations
		//so we use the min-max scaler accordingly for the first 7 terms
		for (int i=0; i<6; i++) {
			normalizedTerms[i]=(terms[i])/10;
		}
		//for the normalized temperature we use a float var and assign it to the index nr.7 of the terms array
		float normalizedTemp;
		normalizedTemp = (terms[7] - 184.0f)/(284.0f - 184.0f);
		normalizedTerms[7]=normalizedTemp;
		//Just following this: 
	    float normalizedClouds;
	    normalizedClouds = terms[8]/100;
		normalizedTerms[8]=normalizedClouds;
		double geodesicDistance= distanceCalculator.distance(23.7162f, 37.9795f, terms[9], terms[10], "K");
        float Distance = Double.valueOf(geodesicDistance).floatValue();
        normalizedTerms[9]= Distance/13396;
        //13396 the distance in kilometres between Athens and Sydney
        //variable of 23.7162 stands for the Athens' Latitude , as 37.9795 for the Longtitude
	    Vector<Float> features = new Vector<Float>();
	    features = new Vector<Float>();
    	 for (int i=0; i<9; i++) {
    		 features.add(normalizedTerms[i]);
    	 }
    		 return (Vector<Float>) features;
    		 
     }
}
	
	

