import java.io.IOException;
import java.util.Date;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

import org.json.JSONException;
import org.json.simple.parser.ParseException;


public class OpenData implements PerceptronTraveller { 
	public static final ArrayList<String> recommendedCities = new ArrayList<String>();
	public static final ArrayList<City> CandidateCities= new ArrayList<City>();
	//@param  citiesTimepstamps creates a new date object which parses in the type of String.
	ArrayList<String> citiesTimestamps = new ArrayList<String>();
	//Q2.3 Create an Jackson Tester object to R/W from/to Json
	JacksonTester tester = new JacksonTester();
	//Keeping a collection of Candidate cities (Parse Json to city object)
	public void PopulateCollection() {
		CandidateCities.add(tester.JsonToCity());
	}
	//Create city objects
	public void insertNewCity() throws IOException, JSONException, ParseException  {
		String cityName;
		String country;
		String appid = "87f7ead88749ce59a63c5e0b593dccd4";
		try (Scanner in = new Scanner(System.in)) {
			System.out.println("Please Provide a Candidate city name:\n");
		    cityName  = in.nextLine();
			System.out.println("Please Provide the city's country(ex.Greece='gr'):\n");
			country = in.nextLine();
		}
		City city = new City();
		city.RetrieveData(cityName, country, appid);
		CandidateCities.add(city);
		citiesTimestamps.add(new Date().toString());
		tester.WriteToJson(city);
		/*int i=0;
		do {
		if (CandidateCities.get(i).getCityName().equals(city.getCityName())){
			System.out.println("City added to Candidate Cities at:"+citiesTimestamps.get(i));
		}else {
			CandidateCities.add(city);
		  	tester.WriteToJson(city);
		  	citiesTimestamps.add(new Date().toString());
		}
		i++;
		}while(CandidateCities.size()>i);
	}
 */
	}
	//Getter of citiesTimpestamps
	public ArrayList<String> getcitiesTimestamps(){
		return citiesTimestamps;
	}
	//q2.1 .put each city to a Collection of cities(Arraylist)
	public ArrayList<City> pushCityToList(City city){
		CandidateCities.add(city);
		return CandidateCities;
	}
	//Candidate cities getter
	public ArrayList<City> getCandidateCities() {
		return CandidateCities;
	}
	Vector<Float> weightBias = new Vector<Float>();
	//Implementation of recommend method of the interface Perceptron Traveller
	public ArrayList<String> recommend(){
		//Created a threshold of 3 . In case the weighted_sum exceeds the threshold ,the City will be recommended
		
		//Created an Array list of Cities
    	ArrayList<City> cities = new ArrayList<City>();
    	cities = new ArrayList<City>();
    	for (int i=0; i<getCandidateCities().size(); i++){
    		//Parsing the Candidate cities to the cities ArrayList 
    	cities=getCandidateCities();
    	}
    	
    	
    	//for each city of the cities Arraylist
    	for (City city : cities) {
    		
    		float weighted_sum=0;
    		//Creating a Vector of cityTerms . This Vector will be used in order to parse 
    		//the vector Represantation of each city's features to it.
    		Vector<Float> cityTerms = new Vector<Float>();
    		cityTerms=city.vectorRepresentation();
    		for (int i=0; i<cityTerms.size(); ++i) {
    			//Calculating the sum of weights to then filter the weighted_sum to the Step Function
    	      weighted_sum += (cityTerms.get(i) * weightBias.get(i));
    	      
      		}
    		//Heavyside stepFunction
    		//This is the Step Function in which the city will be added to the recomendedCities ArrayList 
    		//Only and only if the weighted_sum exceeds the threshold
    		if ( weighted_sum>0.5f) {
      			recommendedCities.add(city.getCityName().toString());	
    		}
    		
    		
    		
    		
    	}
    	return recommendedCities;
    	
    	
		
	}
	public String recommend(boolean exp){
		if (exp==true) {
			return recommendedCities.toString().toUpperCase();
		}else {
			return recommendedCities.toString().toLowerCase();
		}
	}

public static void main(String[] args) throws IOException, JSONException, ParseException {
	OpenData ob = new OpenData();
	ob.insertNewCity();
	System.out.println(ob.getCandidateCities().toString());
	//Prompting the User to insert his/her age */
	/*System.out.println("Please Enter your age , and i'll recommend you some of them! :\n");
	try (Scanner sc = new Scanner(System.in)) {
		int age = sc.nextInt();
		//Checking if the user enters below zero age , too big number of age or age below 16
		while ( age>115 || age<16) {
			System.out.println("Invalid Number! Please provide an integer of your age:\n");
		    age=sc.nextInt();
		}
		if(age>=16 && age<=25) {
			PerceptronYoungTraveller young = new PerceptronYoungTraveller();
			ArrayList<String> RecommendedCities = young.recommend();
			System.out.println("Recommended cities:"+RecommendedCities);
			
		}else if(age>25 && age<=60) {
			PerceptronMiddleTraveller middle = new PerceptronMiddleTraveller();
			ArrayList<String> RecommendedCities = middle.recommend();
			System.out.println("Recommended cities:"+RecommendedCities);
		}else {
			PerceptronElderTraveller elder = new PerceptronElderTraveller();
			ArrayList<String> RecommendedCities = elder.recommend();
			System.out.println("Recommended cities:"+RecommendedCities);
		}
	} */
	 
	
	
	
	

	
}
}