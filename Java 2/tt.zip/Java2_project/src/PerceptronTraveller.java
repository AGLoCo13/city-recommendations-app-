import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;

public interface PerceptronTraveller {
	//public ArrayList<String> recommend(float threshold,Vector<Float> AgeWeight); //Interface method
	public ArrayList<String> recommend(); 
//method recommend of Young,Middle, Elder Traveller
}    	

class PerceptronYoungTraveller implements PerceptronTraveller{
	 //public  ArrayList<String> recommend(boolean exp);
	 Vector<Float> weightBias = new Vector<Float>();
	 ArrayList<String> recommendedCities = new ArrayList<String>();
	 OpenData youngTraveller = new OpenData();
	 public ArrayList<String> recommend(){
		 /*try {
			//youngTraveller.getDataFromAllCities();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} */
		 //youngTraveller.pushCitiesToList();
		 ArrayList<City> candidateCities = youngTraveller.getCandidateCities();
		 float threshold = -0.2f;
		 weightBias.add(-0.1f);
	     weightBias.add(-0.2f);
	     weightBias.add(-0.1f);
	     weightBias.add(0.5f);
	     weightBias.add(0.6f);
	     weightBias.add(-0.1f);
	     weightBias.add(0.3f);
	     weightBias.add(0.6f);
	     weightBias.add(-0.2f);
	     weightBias.add(0.1f);
		   //Created an Array list of Cities
	    	ArrayList<City> cities = new ArrayList<City>();
	    	cities = new ArrayList<City>();
	    	for (int i=0; i<candidateCities.size(); i++){
	    		//Parsing the Candidate cities to the cities ArrayList 
	    	cities=candidateCities;
	    	}
	    	
	    	
	    	//for each city of the cities Arraylist
	    	for (City city : cities) {
	    		
	    		float weighted_sum=0;
	    		//Creating a Vector of cityTerms . This Vector will be used in order to parse 
	    		//the vector Represantation of each city's features to it.
	    		Vector<Float> cityTerms = new Vector<Float>();
	    		cityTerms=city.vectorRepresentation();
	    		for (int i=0; i<cityTerms.size(); ++i) {
	    			//Calculating the sum of weights to then filter the weighted_sum to the Step Function
	    	      weighted_sum += (cityTerms.get(i) * weightBias.get(i));
	    	      
	      		}
	    		//Heavyside stepFunction
	    		//This is the Step Function in which the city will be added to the recomendedCities ArrayList 
	    		//Only and only if the weighted_sum exceeds the threshold
	    		if ( weighted_sum>threshold) {
	      			recommendedCities.add(city.getCityName().toString());	
	    		}
	    		
	    		
	    		
	    		
	    	}
	    	return recommendedCities;
	 }
}

class PerceptronMiddleTraveller implements PerceptronTraveller{
	Vector<Float> weightBias = new Vector<Float>();
	 ArrayList<String> recommendedCities = new ArrayList<String>();
	 OpenData middleTraveller = new OpenData();
	 public ArrayList<String> recommend(){
		 /*try {
			//middleTraveller.getDataFromAllCities();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} */
		 //middleTraveller.pushCitiesToList();
		 ArrayList<City> candidateCities = middleTraveller.getCandidateCities();
		 float threshold = -0.5f;
		 weightBias.add(-0.2f);
	     weightBias.add(-0.1f);
	     weightBias.add(0.2f);
	     weightBias.add(0.6f);
	     weightBias.add(0.4f);
	     weightBias.add(0.2f);
	     weightBias.add(0.3f);
	     weightBias.add(0.5f);
	     weightBias.add(0.2f);
	     weightBias.add(0.2f);
	   //Created an Array list of Cities
	    	ArrayList<City> cities = new ArrayList<City>();
	    	cities = new ArrayList<City>();
	    	for (int i=0; i<candidateCities.size(); i++){
	    		//Parsing the Candidate cities to the cities ArrayList 
	    	cities=candidateCities;
	    	}
	    	
	    	
	    	//for each city of the cities Arraylist
	    	for (City city : cities) {
	    		
	    		float weighted_sum=0;
	    		//Creating a Vector of cityTerms . This Vector will be used in order to parse 
	    		//the vector Represantation of each city's features to it.
	    		Vector<Float> cityTerms = new Vector<Float>();
	    		cityTerms=city.vectorRepresentation();
	    		for (int i=0; i<cityTerms.size(); ++i) {
	    			//Calculating the sum of weights to then filter the weighted_sum to the Step Function
	    	      weighted_sum += (cityTerms.get(i) * weightBias.get(i));
	    	      
	      		}
	    		//Heavyside stepFunction
	    		//This is the Step Function in which the city will be added to the recomendedCities ArrayList 
	    		//Only and only if the weighted_sum exceeds the threshold
	    		if ( weighted_sum>threshold) {
	      			recommendedCities.add(city.getCityName().toString());	
	    		}
	    		
	    		
	    		
	    		
	    	}
	    	return recommendedCities;
	 }
}
	

	
class PerceptronElderTraveller implements PerceptronTraveller{
	Vector<Float> weightBias = new Vector<Float>();
	 ArrayList<String> recommendedCities = new ArrayList<String>();
	 OpenData elderTraveller = new OpenData();
	 public ArrayList<String> recommend(){
		 /*try {
			//elderTraveller.getDataFromAllCities();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} */
		 //elderTraveller.pushCitiesToList();
		 ArrayList<City> candidateCities = elderTraveller.getCandidateCities();
		 float threshold = -0.5f;
		 weightBias.add(-0.5f);
	     weightBias.add(-0.5f);
	     weightBias.add(0.4f);
	     weightBias.add(0.4f);
	     weightBias.add(0.5f);
	     weightBias.add(0.4f);
	     weightBias.add(0.3f);
	     weightBias.add(-0.2f);
	     weightBias.add(0.4f);
	     weightBias.add(0.2f);
	   //Created an Array list of Cities
	    	ArrayList<City> cities = new ArrayList<City>();
	    	cities = new ArrayList<City>();
	    	for (int i=0; i<candidateCities.size(); i++){
	    		//Parsing the Candidate cities to the cities ArrayList 
	    	cities=candidateCities;
	    	}
	    	
	    	
	    	//for each city of the cities Arraylist
	    	for (City city : cities) {
	    		
	    		float weighted_sum=0;
	    		//Creating a Vector of cityTerms . This Vector will be used in order to parse 
	    		//the vector Represantation of each city's features to it.
	    		Vector<Float> cityTerms = new Vector<Float>();
	    		cityTerms=city.vectorRepresentation();
	    		for (int i=0; i<cityTerms.size(); ++i) {
	    			//Calculating the sum of weights to then filter the weighted_sum to the Step Function
	    	      weighted_sum += (cityTerms.get(i) * weightBias.get(i));
	    	      
	      		}
	    		//Heavyside stepFunction
	    		//This is the Step Function in which the city will be added to the recomendedCities ArrayList 
	    		//Only and only if the weighted_sum exceeds the threshold
	    		if ( weighted_sum>threshold) {
	      			recommendedCities.add(city.getCityName().toString());	
	    		}
	    		
	    		
	    		
	    		
	    	}
	    	return recommendedCities;
	 }
}




