import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONArray;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
//For Q2.3 i created a new class named JacksonTester that will be  used in order to R/W to the JSON
//of Cities
//@JsonIgnoreProperties(ignoreUnknown = true)
public class JacksonTester {
	
	public void writeCityToJSON(City city) throws JsonGenerationException, JsonMappingException, IOException{
		try{// create object mapper instance
	    InputStream inputstr = new FileInputStream(new File("cities.json"));
	    ObjectMapper mapper = new ObjectMapper();
	    city.getCityName();
		city.getCountry();
	    city.getTemperature();
        city.getLatitude();
        city.getLongtitude();
        city.getCountry();
        city.getMountainCount();
        city.getMuseumCount();
        city.getSeaCount();
        city.getClouds();
        city.getEtcCount();
         city.getStadiumCount();
	    // convert book object to JSON file
	    mapper.writeValue(new File("cities.json"), city);
	    inputstr.close();

	} catch (Exception ex) {
	    ex.printStackTrace();
	}
	   }
	public void readCitiesFromJSON() throws FileNotFoundException {
		ObjectMapper mapper = new ObjectMapper();
		InputStream inputStr = new FileInputStream(new File("cities.json"));
		TypeReference<ArrayList<City>> typereference = new TypeReference<ArrayList<City>>() {};
		ArrayList<City> cities = new ArrayList<City>();
		for (City c : cities) {
			c.getCityName();
			c.getCountry();
		    c.getTemperature();
	        c.getLatitude();
	        c.getLongtitude();
	        c.getCountry();
	        c.getMountainCount();
	        c.getMuseumCount();
	        c.getSeaCount();
	        c.getClouds();
	        c.getEtcCount();
	        c.getStadiumCount();
		}
		
		
	}
	public void writeAllCitiesToJson(ArrayList<City> Cities) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.writeValue(Paths.get("cities.json").toFile(), Cities);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
   public City JsonToCity() {
	   City city = new City();
	   try {
		   ObjectMapper  mapper = new ObjectMapper();
		    city = mapper.readValue("cities.json", City.class);
		   
	   }catch(Exception ex) {
		   ex.printStackTrace();
	   }
	   return city;
   }
	   public void readJSON() throws JsonParseException, JsonMappingException, IOException{
	      ObjectMapper mapper = new ObjectMapper();
	      mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	      mapper.setVisibility(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
	      City[] city = mapper.readValue(new File("cities.json"), City[].class);
	      List<City> cityList = new ArrayList<City>(Arrays.asList(city));
	      cityList.forEach(x ->System.out.println(x.toString()));
	   }
	 //Json Checker for checking if city name exists in cities.json
	   public boolean hasValue(String key,String value) {
			JsonArray json = new JsonArray();
			Gson g = new Gson();
			json = g.fromJson("cities.json", JsonArray.class);
			for ( int i=0; i<json.size(); i++) {
				if(json.get(i).getAsJsonObject().get(key).getAsString().equals(value)) return true;
		    }
		    return false;
		}
	 
	@SuppressWarnings("unchecked")
	public void WriteToJson(City city) throws JSONException, IOException, ParseException {
	            // Create a new JSONObject
		        JSONParser parser = new JSONParser();
		        JSONObject outer = new JSONObject();
		        JSONObject inner = new JSONObject();
		        JSONObject data = new JSONObject();
		        ArrayList<JSONObject> arr = new ArrayList<JSONObject>();
	            inner.put("cityName",city.getCityName());
	            inner.put("country",city.getCountry());
	            inner.put("temperature",city.getTemperature());
	            inner.put("latitude",city.getLatitude());
	            inner.put("longtitude",city.getLongtitude());
	            inner.put("clouds",city.getClouds());
	            inner.put("mountains",city.getMountainCount());
	            inner.put("museums",city.getMuseumCount());
	            inner.put("Seas",city.getSeaCount());
	            inner.put("etc",city.getEtcCount());
	            inner.put("stadiums",city.getStadiumCount());
	            inner.put("cafe", city.getCafeCount());
                arr.add(inner);
                outer.put("City",arr);
                File file = new File("cities.json");
                if(file.exists()) {
                    Object obj = parser.parse(new FileReader("cities.json"));
                    JSONObject jsonObject = (JSONObject) obj;
                    JSONArray array = (JSONArray) jsonObject.get("City");
                    PrintWriter write = new PrintWriter(new FileWriter(file));
                    Iterator<JSONObject> iterator = array.iterator();
                    while(iterator.hasNext()) {
                        JSONObject it = iterator.next();
                        data = (JSONObject) it; 
                        System.out.println("Data" + data);
                        arr.add(data);
                        }
                    arr.add(inner);
                    System.out.println(arr);
                    outer.put("City", arr);
                    System.out.println("Dati: " + outer);
                    write.write(outer.toString());
                    write.flush();
                    write.close();
            }
}
}
	


